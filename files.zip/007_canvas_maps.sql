-- supabase/migrations/007_canvas_maps.sql
-- Mapeamento Visual: canvas de leitura de Price Action
-- Três tabelas: mapa (metadata), nós (elementos) e arestas (conexões)

-- 1. Tabela principal de mapas
CREATE TABLE IF NOT EXISTS canvas_maps (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title        TEXT NOT NULL DEFAULT 'Novo mapa',
  tags         TEXT[] NOT NULL DEFAULT '{}',
  description  TEXT NOT NULL DEFAULT '',
  thumbnail    TEXT NOT NULL DEFAULT '',   -- base64 mini-preview
  viewport_x   FLOAT NOT NULL DEFAULT 0,
  viewport_y   FLOAT NOT NULL DEFAULT 0,
  viewport_scale FLOAT NOT NULL DEFAULT 1,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_canvas_maps_updated ON canvas_maps(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_canvas_maps_tags    ON canvas_maps USING gin(tags);

-- 2. Nós do canvas
-- type: 'phase' | 'setup' | 'pattern' | 'image' | 'note' | 'level' | 'concept'
-- data: payload flexível por tipo (ver comentários abaixo)
CREATE TABLE IF NOT EXISTS canvas_nodes (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  map_id      UUID NOT NULL REFERENCES canvas_maps(id) ON DELETE CASCADE,
  type        TEXT NOT NULL CHECK (type IN ('phase','setup','pattern','image','note','level','concept')),
  x           FLOAT NOT NULL DEFAULT 100,
  y           FLOAT NOT NULL DEFAULT 100,
  width       FLOAT NOT NULL DEFAULT 160,
  height      FLOAT NOT NULL DEFAULT 60,
  z_index     INT NOT NULL DEFAULT 0,
  data        JSONB NOT NULL DEFAULT '{}',
  -- data por type:
  --   phase:   { label, phase_type, direction:'alta'|'baixa'|'lateral', color }
  --   setup:   { label, setup_type, direction, probability, notes }
  --   pattern: { label, pattern_type, reliability:'alta'|'media'|'baixa', notes }
  --   image:   { url, caption, storage_path }
  --   note:    { text, color }
  --   level:   { label, price, level_type:'support'|'resistance'|'target', color }
  --   concept: { concept_id, concept_name, mastery }
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_canvas_nodes_map ON canvas_nodes(map_id);

-- 3. Arestas (conexões entre nós)
CREATE TABLE IF NOT EXISTS canvas_edges (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  map_id      UUID NOT NULL REFERENCES canvas_maps(id) ON DELETE CASCADE,
  source_id   UUID NOT NULL,
  target_id   UUID NOT NULL,
  edge_type   TEXT NOT NULL DEFAULT 'arrow' CHECK (edge_type IN ('arrow','dashed','bidirectional')),
  label       TEXT NOT NULL DEFAULT '',
  color       TEXT NOT NULL DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_canvas_edges_map ON canvas_edges(map_id);

-- 4. Permissões (single-user, sem auth)
ALTER TABLE canvas_maps  DISABLE ROW LEVEL SECURITY;
ALTER TABLE canvas_nodes DISABLE ROW LEVEL SECURITY;
ALTER TABLE canvas_edges DISABLE ROW LEVEL SECURITY;
