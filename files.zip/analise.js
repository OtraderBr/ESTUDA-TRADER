// js/analise.js
// Mapeamento Visual — canvas de leitura de Price Action (Al Brooks)
// Arquitetura: Gallery → Editor com sidebar direita retrátil
// Funcionalidades: nós tipados, arestas bezier, paste de imagem, auto-save Supabase

import { supabase } from './supabaseClient.js';
import { store } from './state.js';

const BUCKET = 'concept-images';

/* ─── TAXONOMIA DE CARDS ───────────────────────────────────────────────────── */

const CARD_LIBRARY = {
  phase: {
    label: 'Ciclo de Mercado',
    icon: '📈',
    color: '#d97706',        // amber
    fillLight: '#fef3c7',
    fillDark:  '#92400e',
    items: [
      { subtype: 'trend_high',    label: 'Tendência Alta',     abbr: 'TA',  dir: 'alta'    },
      { subtype: 'trend_low',     label: 'Tendência Baixa',    abbr: 'TB',  dir: 'baixa'   },
      { subtype: 'channel_tight', label: 'Canal Estreito',     abbr: 'CE',  dir: null      },
      { subtype: 'channel_broad', label: 'Canal Amplo',        abbr: 'CA',  dir: null      },
      { subtype: 'range',         label: 'Trading Range',      abbr: 'TR',  dir: null      },
      { subtype: 'ttr',           label: 'TTR (Tight Range)',  abbr: 'TTR', dir: null      },
      { subtype: 'breakout',      label: 'Rompimento',         abbr: 'BO',  dir: null      },
      { subtype: 'micro_channel', label: 'Micro Canal',        abbr: 'MC',  dir: null      },
      { subtype: 'climax',        label: 'Clímax',             abbr: 'CLI', dir: null      },
    ],
  },
  setup: {
    label: 'Setup / Gatilho',
    icon: '⚡',
    color: '#dc2626',
    fillLight: '#fee2e2',
    fillDark:  '#7f1d1d',
    items: [
      { subtype: 'h1',       label: 'H1 — First Pullback',    abbr: 'H1'  },
      { subtype: 'h2',       label: 'H2 — Second Entry',      abbr: 'H2'  },
      { subtype: 'l1',       label: 'L1 — First Rally',       abbr: 'L1'  },
      { subtype: 'l2',       label: 'L2 — Second Entry',      abbr: 'L2'  },
      { subtype: 'mtr',      label: 'MTR — Major Reversal',   abbr: 'MTR' },
      { subtype: 'failed_bo',label: 'Failed BO',              abbr: 'FBO' },
      { subtype: 'btc',      label: 'BTC — Buy the Close',    abbr: 'BTC' },
      { subtype: 'stc',      label: 'STC — Sell the Close',   abbr: 'STC' },
      { subtype: 'blshs',    label: 'BLSHS',                  abbr: '↕'   },
    ],
  },
  pattern: {
    label: 'Padrão',
    icon: '🔀',
    color: '#7c3aed',
    fillLight: '#ede9fe',
    fillDark:  '#4c1d95',
    items: [
      { subtype: 'bull_flag',     label: 'Bull Flag',          abbr: '🏳↑'  },
      { subtype: 'bear_flag',     label: 'Bear Flag',          abbr: '🏳↓'  },
      { subtype: 'wedge_high',    label: 'Cunha Altista',      abbr: 'W↑'   },
      { subtype: 'wedge_low',     label: 'Cunha Baixista',     abbr: 'W↓'   },
      { subtype: 'double_top',    label: 'Duplo Topo',         abbr: 'DT'   },
      { subtype: 'double_bottom', label: 'Duplo Fundo',        abbr: 'DF'   },
      { subtype: 'inside_bar',    label: 'Inside Bar (ii)',    abbr: 'ii'   },
      { subtype: 'hns',           label: 'Head & Shoulders',   abbr: 'OHO'  },
      { subtype: 'trap',          label: 'Armadilha',          abbr: 'TRAP' },
      { subtype: 'climax_bar',    label: 'Barra de Clímax',   abbr: 'CLX'  },
    ],
  },
  mark: {
    label: 'Marcação',
    icon: '📌',
    color: '#0891b2',
    fillLight: '#e0f2fe',
    fillDark:  '#164e63',
    items: [
      { subtype: 'support',    label: 'Suporte',         abbr: 'S'   },
      { subtype: 'resistance', label: 'Resistência',     abbr: 'R'   },
      { subtype: 'target',     label: 'Alvo / MM',       abbr: 'MM'  },
      { subtype: 'note_free',  label: 'Nota Livre',      abbr: '✏️'  },
      { subtype: 'image',      label: 'Imagem/Print',    abbr: '🖼'  },
      { subtype: 'concept',    label: 'Conceito do BD',  abbr: '📚'  },
    ],
  },
};

/* ─── ESTADO LOCAL ─────────────────────────────────────────────────────────── */

let _view         = 'gallery';   // 'gallery' | 'editor'
let _currentMapId = null;
let _canvas       = { nodes: [], edges: [], viewport: { x: 0, y: 0, scale: 1 } };
let _sidebarOpen  = true;
let _maps         = [];
let _container    = null;
let _saveTimer    = null;
let _isDraggingNode  = false;
let _isDraggingEdge  = false;
let _dragNodeId      = null;
let _dragStartX      = 0;
let _dragStartY      = 0;
let _nodeStartX      = 0;
let _nodeStartY      = 0;
let _edgeSourceId    = null;
let _edgeSourceSide  = null;
let _isPanning       = false;
let _panStartX       = 0;
let _panStartY       = 0;
let _hasDragged      = false;
let _selectedNodeId  = null;
let _selectedEdgeId  = null;
let _edgeTempEl      = null;   // SVG path for in-progress edge
let _openCategoryKey = null;
let _modalOpen       = false;
let _editNodeId      = null;

const _globalHandlers = [];
function _addGlobal(type, fn, opts) {
  window.addEventListener(type, fn, opts);
  _globalHandlers.push({ type, fn, opts });
}
function _cleanGlobal() {
  _globalHandlers.forEach(({ type, fn, opts }) => window.removeEventListener(type, fn, opts));
  _globalHandlers.length = 0;
}

function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() :
    'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
}

/* ─── SUPABASE CRUD ─────────────────────────────────────────────────────────── */

async function loadAllMaps() {
  const { data, error } = await supabase
    .from('canvas_maps')
    .select('id, title, tags, description, thumbnail, updated_at')
    .order('updated_at', { ascending: false });
  if (error) { console.error('loadAllMaps:', error); return []; }
  return data || [];
}

async function loadMap(mapId) {
  const [{ data: map }, { data: nodes }, { data: edges }] = await Promise.all([
    supabase.from('canvas_maps').select('*').eq('id', mapId).single(),
    supabase.from('canvas_nodes').select('*').eq('map_id', mapId),
    supabase.from('canvas_edges').select('*').eq('map_id', mapId),
  ]);
  return {
    map:   map   || {},
    nodes: nodes || [],
    edges: edges || [],
  };
}

async function createMap() {
  const { data, error } = await supabase
    .from('canvas_maps')
    .insert({ title: 'Novo mapa', tags: [], description: '' })
    .select('id')
    .single();
  if (error) { console.error('createMap:', error); return null; }
  return data.id;
}

async function saveMapMetadata(mapId, title, tags, description, viewport) {
  const { error } = await supabase
    .from('canvas_maps')
    .update({
      title, tags, description,
      viewport_x: viewport.x,
      viewport_y: viewport.y,
      viewport_scale: viewport.scale,
      updated_at: new Date().toISOString(),
    })
    .eq('id', mapId);
  if (error) console.error('saveMapMetadata:', error);
}

async function upsertNode(node, mapId) {
  const { error } = await supabase
    .from('canvas_nodes')
    .upsert({
      id: node.id, map_id: mapId,
      type: node.type, x: node.x, y: node.y,
      width: node.width, height: node.height,
      z_index: node.zIndex || 0, data: node.data || {},
    }, { onConflict: 'id' });
  if (error) console.error('upsertNode:', error);
}

async function deleteNodeDB(nodeId) {
  await supabase.from('canvas_nodes').delete().eq('id', nodeId);
}

async function upsertEdge(edge, mapId) {
  const { error } = await supabase
    .from('canvas_edges')
    .upsert({
      id: edge.id, map_id: mapId,
      source_id: edge.sourceId, target_id: edge.targetId,
      edge_type: edge.edgeType || 'arrow',
      label: edge.label || '', color: edge.color || '',
    }, { onConflict: 'id' });
  if (error) console.error('upsertEdge:', error);
}

async function deleteEdgeDB(edgeId) {
  await supabase.from('canvas_edges').delete().eq('id', edgeId);
}

async function deleteMapDB(mapId) {
  await supabase.from('canvas_maps').delete().eq('id', mapId);
}

async function uploadImageFile(file) {
  if (!file?.type?.startsWith('image/')) return null;
  if (file.size > 5 * 1024 * 1024) { alert('Imagem muito grande. Limite: 5 MB.'); return null; }
  const ext = file.name.split('.').pop() || 'png';
  const path = `canvas-images/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { cacheControl: '3600', upsert: false });
  if (error) { console.error('uploadImage:', error); return null; }
  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
  return { url: data.publicUrl, path };
}

/* ─── PONTO DE ENTRADA ──────────────────────────────────────────────────────── */

export async function renderAnalise(container) {
  _cleanGlobal();
  _container = container;
  _maps = await loadAllMaps();
  _view = 'gallery';
  _render();
}

function _render() {
  if (!_container) return;
  if (_view === 'gallery') {
    _renderGallery();
  } else {
    _renderEditor();
  }
}

/* ─── GALLERY VIEW ──────────────────────────────────────────────────────────── */

function _renderGallery() {
  _container.innerHTML = `
    <div class="flex flex-col h-full" id="gallery-root">
      <div class="px-6 pt-5 pb-4 border-b border-zinc-200 bg-white shrink-0">
        <div class="flex items-center justify-between">
          <div>
            <h1 class="text-[17px] font-bold text-zinc-900">Mapeamento Visual</h1>
            <p class="text-xs text-zinc-400 mt-0.5">Canvas de leitura de Price Action (Al Brooks)</p>
          </div>
          <button id="new-map-btn"
            class="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-white px-4 py-2 rounded-xl text-xs font-semibold transition-colors">
            <i data-lucide="plus" class="w-3.5 h-3.5"></i> Novo Canvas
          </button>
        </div>
        <!-- Search / filter -->
        <div class="mt-4 relative">
          <i data-lucide="search" class="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"></i>
          <input id="gallery-search" type="text" placeholder="Buscar por título ou tag..."
            class="w-full bg-zinc-50 border border-zinc-200 rounded-xl pl-9 pr-4 py-2 text-sm text-zinc-800 placeholder:text-zinc-400 focus:outline-none focus:border-zinc-400 transition-colors"/>
        </div>
      </div>

      <div class="flex-1 overflow-y-auto p-6">
        ${_maps.length === 0 ? `
          <div class="flex flex-col items-center justify-center h-full text-center py-20">
            <div class="w-20 h-20 bg-zinc-100 rounded-2xl flex items-center justify-center mb-4">
              <i data-lucide="map" class="w-10 h-10 text-zinc-300"></i>
            </div>
            <p class="text-sm font-semibold text-zinc-500 mb-1">Nenhum canvas ainda</p>
            <p class="text-xs text-zinc-400 mb-5">Crie seu primeiro mapa de leitura de Price Action</p>
            <button id="new-map-btn-empty"
              class="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 text-white px-5 py-2.5 rounded-xl text-xs font-semibold transition-colors">
              <i data-lucide="plus" class="w-3.5 h-3.5"></i> Criar canvas
            </button>
          </div>
        ` : `
          <div id="gallery-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            ${_maps.map(m => _galleryCard(m)).join('')}
          </div>
        `}
      </div>
    </div>
  `;
  if (window.lucide) window.lucide.createIcons();

  document.getElementById('new-map-btn')?.addEventListener('click', _handleNewMap);
  document.getElementById('new-map-btn-empty')?.addEventListener('click', _handleNewMap);

  document.getElementById('gallery-search')?.addEventListener('input', e => {
    const q = e.target.value.toLowerCase().trim();
    const grid = document.getElementById('gallery-grid');
    if (!grid) return;
    grid.querySelectorAll('.gallery-card').forEach(card => {
      const title = (card.getAttribute('data-title') || '').toLowerCase();
      const tags  = (card.getAttribute('data-tags')  || '').toLowerCase();
      card.classList.toggle('hidden', q.length > 0 && !title.includes(q) && !tags.includes(q));
    });
  });

  _container.querySelectorAll('.gallery-card-open').forEach(btn => {
    btn.addEventListener('click', async () => {
      const mapId = btn.getAttribute('data-id');
      await _openEditor(mapId);
    });
  });

  _container.querySelectorAll('.gallery-card-delete').forEach(btn => {
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      const mapId = btn.getAttribute('data-id');
      if (!confirm('Excluir este canvas permanentemente?')) return;
      await deleteMapDB(mapId);
      _maps = _maps.filter(m => m.id !== mapId);
      _render();
    });
  });
}

function _galleryCard(m) {
  const date = m.updated_at ? new Date(m.updated_at).toLocaleDateString('pt-BR') : '';
  const tags = (m.tags || []).map(t =>
    `<span class="text-[10px] bg-zinc-100 text-zinc-600 px-2 py-0.5 rounded-full border border-zinc-200 font-medium">${t}</span>`
  ).join('');

  return `
    <div class="gallery-card bg-white border border-zinc-200 hover:border-zinc-300 hover:shadow-md rounded-2xl overflow-hidden transition-all group cursor-pointer gallery-card-open"
      data-id="${m.id}" data-title="${(m.title||'').toLowerCase()}" data-tags="${(m.tags||[]).join(' ').toLowerCase()}">
      <!-- Thumbnail -->
      <div class="h-28 bg-zinc-50 border-b border-zinc-100 flex items-center justify-center relative overflow-hidden">
        ${m.thumbnail
          ? `<img src="${m.thumbnail}" class="w-full h-full object-cover" alt="">`
          : `<i data-lucide="map" class="w-10 h-10 text-zinc-200"></i>`
        }
        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors"></div>
        <button class="gallery-card-delete absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 bg-white/90 hover:bg-red-50 rounded-lg text-zinc-400 hover:text-red-500 transition-all shadow-sm"
          data-id="${m.id}" title="Excluir">
          <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
        </button>
      </div>
      <!-- Info -->
      <div class="p-4">
        <h3 class="text-sm font-semibold text-zinc-900 truncate mb-1">${m.title || 'Sem título'}</h3>
        ${m.description ? `<p class="text-xs text-zinc-400 mb-2 line-clamp-2">${m.description}</p>` : ''}
        <div class="flex flex-wrap gap-1 mb-2">${tags}</div>
        <div class="text-[10px] text-zinc-300">${date}</div>
      </div>
    </div>
  `;
}

async function _handleNewMap() {
  const mapId = await createMap();
  if (mapId) await _openEditor(mapId);
}

/* ─── EDITOR VIEW ───────────────────────────────────────────────────────────── */

async function _openEditor(mapId) {
  const { map, nodes, edges } = await loadMap(mapId);
  _currentMapId = mapId;
  _canvas = {
    nodes: nodes.map(n => ({
      id: n.id, type: n.type,
      x: n.x, y: n.y, width: n.width, height: n.height,
      zIndex: n.z_index || 0, data: n.data || {}
    })),
    edges: edges.map(e => ({
      id: e.id, sourceId: e.source_id, targetId: e.target_id,
      edgeType: e.edge_type || 'arrow', label: e.label || '', color: e.color || ''
    })),
    viewport: {
      x: map.viewport_x || 0,
      y: map.viewport_y || 0,
      scale: map.viewport_scale || 1,
    },
    title: map.title || 'Novo mapa',
    tags: map.tags || [],
    description: map.description || '',
  };
  _selectedNodeId  = null;
  _selectedEdgeId  = null;
  _view = 'editor';
  _render();
}

function _renderEditor() {
  const sbW = _sidebarOpen ? 248 : 0;
  const toggleIcon = _sidebarOpen ? '›' : '‹';

  _container.innerHTML = `
    <div class="flex flex-col h-full" id="editor-root">

      <!-- Top bar -->
      <div class="flex items-center gap-3 px-4 py-2.5 border-b border-zinc-200 bg-white shrink-0 z-10">
        <button id="editor-back-btn"
          class="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-800 bg-zinc-100 hover:bg-zinc-200 px-3 py-1.5 rounded-lg transition-colors font-medium">
          <i data-lucide="arrow-left" class="w-3.5 h-3.5"></i> Mapas
        </button>
        <div class="w-px h-4 bg-zinc-200"></div>
        <input id="editor-title" type="text" value="${_escAttr(_canvas.title)}"
          placeholder="Título do canvas..."
          class="flex-1 text-sm font-semibold text-zinc-900 bg-transparent border-none outline-none placeholder:text-zinc-300 max-w-xs"/>
        <div class="flex items-center gap-2 ml-auto">
          <span id="save-badge" class="text-[10px] text-emerald-600 font-medium opacity-0 transition-opacity flex items-center gap-1">
            <i data-lucide="check-circle" class="w-3 h-3"></i> Salvo
          </span>
          <button id="editor-tags-btn"
            class="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-800 bg-zinc-100 hover:bg-zinc-200 px-3 py-1.5 rounded-lg transition-colors">
            <i data-lucide="tag" class="w-3.5 h-3.5"></i>
            ${_canvas.tags.length > 0 ? `<span class="bg-zinc-900 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold">${_canvas.tags.length}</span>` : ''}
            Tags
          </button>
          <button id="editor-info-btn"
            class="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 transition-colors" title="Descrição">
            <i data-lucide="info" class="w-4 h-4"></i>
          </button>
          <button id="clear-canvas-btn"
            class="flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 hover:bg-red-50 px-2.5 py-1.5 rounded-lg transition-colors" title="Limpar canvas">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </div>
      </div>

      <!-- Canvas + sidebar -->
      <div class="flex flex-1 overflow-hidden relative">

        <!-- Canvas area -->
        <div id="canvas-container" class="flex-1 relative overflow-hidden bg-[#f8fafc] select-none"
          style="background-image: radial-gradient(#e2e8f0 1px, transparent 1px); background-size: 24px 24px;">

          <!-- Transform layer -->
          <div id="canvas-transform" class="absolute inset-0 origin-top-left will-change-transform">
            <svg id="edges-svg" class="absolute inset-0 overflow-visible pointer-events-none w-full h-full"
              style="width:9999px;height:9999px;">
              <defs>
                <marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M2 1.5L8.5 5L2 8.5" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </marker>
                <marker id="ah-dashed" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M2 1.5L8.5 5L2 8.5" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </marker>
              </defs>
              <g id="edges-layer"></g>
              <path id="edge-temp" fill="none" stroke="#6366f1" stroke-width="1.5" stroke-dasharray="5 4"
                marker-end="url(#ah)" style="pointer-events:none; display:none;"/>
            </svg>
            <div id="nodes-layer" class="absolute inset-0 w-full h-full" style="width:9999px;height:9999px;pointer-events:none;"></div>
          </div>

          <!-- Toolbar float (bottom left) -->
          <div class="absolute bottom-4 left-4 flex items-center gap-1.5 z-20">
            <button id="zoom-in-btn"
              class="w-8 h-8 bg-white border border-zinc-200 rounded-lg text-zinc-600 hover:bg-zinc-50 flex items-center justify-center shadow-sm transition-colors text-sm font-bold">+</button>
            <span id="zoom-label" class="text-[10px] text-zinc-400 min-w-[40px] text-center font-mono">100%</span>
            <button id="zoom-out-btn"
              class="w-8 h-8 bg-white border border-zinc-200 rounded-lg text-zinc-600 hover:bg-zinc-50 flex items-center justify-center shadow-sm transition-colors text-sm font-bold">-</button>
            <button id="zoom-reset-btn"
              class="px-2.5 h-8 bg-white border border-zinc-200 rounded-lg text-zinc-500 text-[10px] hover:bg-zinc-50 shadow-sm transition-colors font-medium">Reset</button>
          </div>

          <!-- Hints -->
          <div id="canvas-hints" class="absolute bottom-4 right-${_sidebarOpen ? '256' : '12'} flex items-center gap-3 text-[10px] text-zinc-400 z-10 pointer-events-none">
            <span>Arraste canvas com drag</span>
            <span>·</span>
            <span>Ctrl+V cola imagem</span>
            <span>·</span>
            <span>Del/Backspace exclui seleção</span>
          </div>
        </div>

        <!-- Right sidebar -->
        <aside id="right-sidebar"
          class="shrink-0 border-l border-zinc-200 bg-white flex flex-col h-full transition-all duration-200 overflow-hidden"
          style="width: ${sbW}px;">
          ${_sidebarOpen ? _renderSidebarContent() : ''}
        </aside>

        <!-- Sidebar toggle button -->
        <button id="sidebar-toggle"
          class="absolute right-0 top-1/2 -translate-y-1/2 z-20 w-5 h-12 bg-white border-l border-t border-b border-zinc-200 flex items-center justify-center text-zinc-400 hover:text-zinc-700 hover:bg-zinc-50 transition-colors rounded-l-lg shadow-sm text-xs font-bold"
          style="right: ${sbW}px;"
          title="${_sidebarOpen ? 'Recolher sidebar' : 'Expandir sidebar'}">
          ${toggleIcon}
        </button>
      </div>

      <!-- Tags modal -->
      <div id="tags-modal" class="hidden fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center">
        <div class="bg-white rounded-2xl shadow-xl w-80 p-5">
          <h3 class="text-sm font-bold text-zinc-800 mb-3">Tags do Canvas</h3>
          <div id="tags-current" class="flex flex-wrap gap-1.5 mb-3 min-h-[28px]">
            ${_canvas.tags.map(t => `
              <span class="flex items-center gap-1 text-xs bg-zinc-100 text-zinc-700 px-2 py-1 rounded-lg border border-zinc-200">
                ${t}
                <button class="tag-remove hover:text-red-500 transition-colors leading-none" data-tag="${t}">×</button>
              </span>`).join('')}
          </div>
          <div class="flex gap-2">
            <input id="tag-input" type="text" placeholder="Nova tag + Enter..."
              class="flex-1 text-xs bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-400 transition-colors"/>
            <button id="tag-add-btn"
              class="px-3 py-2 bg-zinc-900 text-white text-xs font-semibold rounded-lg hover:bg-zinc-800 transition-colors">+</button>
          </div>
          <div class="flex justify-end mt-4">
            <button id="tags-modal-close" class="text-xs text-zinc-500 hover:text-zinc-700 bg-zinc-100 hover:bg-zinc-200 px-3 py-1.5 rounded-lg transition-colors">Fechar</button>
          </div>
        </div>
      </div>

      <!-- Node edit modal -->
      <div id="node-modal" class="hidden fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center">
        <div class="bg-white rounded-2xl shadow-xl w-96 p-5" id="node-modal-content"></div>
      </div>
    </div>
  `;

  if (window.lucide) window.lucide.createIcons();

  _renderNodes();
  _renderEdges();
  _applyViewport();
  _bindEditorEvents();
}

function _renderSidebarContent() {
  return `
    <div class="flex items-center justify-between px-4 py-3 border-b border-zinc-100 shrink-0">
      <span class="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Biblioteca</span>
      <span class="text-[10px] text-zinc-400">arraste para o canvas</span>
    </div>
    <div class="flex-1 overflow-y-auto py-2 px-2 space-y-1.5">
      ${Object.entries(CARD_LIBRARY).map(([key, cat]) => _renderCategory(key, cat)).join('')}
    </div>
    <div class="border-t border-zinc-100 px-3 py-2.5 shrink-0">
      <p class="text-[10px] text-zinc-400 leading-relaxed">
        <strong>Ctrl+V</strong> cola imagem · <strong>Del</strong> exclui · arraste handle para conectar
      </p>
    </div>
  `;
}

function _renderCategory(key, cat) {
  const isOpen = _openCategoryKey === key;
  return `
    <div class="sidebar-category rounded-xl border border-zinc-200 overflow-hidden" data-cat-key="${key}">
      <button class="cat-header w-full flex items-center gap-2.5 px-3 py-2.5 hover:bg-zinc-50 transition-colors text-left" data-cat-key="${key}">
        <span class="text-sm">${cat.icon}</span>
        <span class="flex-1 text-xs font-semibold text-zinc-700">${cat.label}</span>
        <i data-lucide="chevron-${isOpen ? 'up' : 'down'}" class="w-3.5 h-3.5 text-zinc-400 shrink-0"></i>
      </button>
      <div class="cat-items ${isOpen ? '' : 'hidden'} px-2 pb-2 space-y-1">
        ${cat.items.map(item => `
          <div class="sidebar-card group cursor-grab active:cursor-grabbing flex items-center gap-2.5 px-3 py-2 rounded-lg border border-transparent hover:border-zinc-200 hover:bg-zinc-50 transition-all"
            draggable="true"
            data-card-type="${key === 'mark' ? item.subtype : key}"
            data-card-subtype="${item.subtype}"
            data-card-label="${item.label}">
            <div class="w-7 h-7 rounded-md flex items-center justify-center shrink-0 text-[10px] font-bold"
              style="background:${cat.fillLight}; color:${cat.color};">${item.abbr}</div>
            <span class="text-xs text-zinc-600 group-hover:text-zinc-900 leading-tight">${item.label}</span>
            <i data-lucide="grip-vertical" class="w-3.5 h-3.5 text-zinc-300 ml-auto opacity-0 group-hover:opacity-100"></i>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

/* ─── NODE RENDERING ────────────────────────────────────────────────────────── */

const NODE_COLORS = {
  phase:   { bg: '#fffbeb', border: '#fcd34d', text: '#92400e', accent: '#d97706' },
  setup:   { bg: '#fff1f2', border: '#fda4af', text: '#9f1239', accent: '#dc2626' },
  pattern: { bg: '#faf5ff', border: '#d8b4fe', text: '#6b21a8', accent: '#7c3aed' },
  image:   { bg: '#f0f9ff', border: '#bae6fd', text: '#0c4a6e', accent: '#0891b2' },
  note:    { bg: '#fefce8', border: '#fde047', text: '#713f12', accent: '#ca8a04' },
  level:   { bg: '#f0fdf4', border: '#86efac', text: '#14532d', accent: '#16a34a' },
  concept: { bg: '#eff6ff', border: '#93c5fd', text: '#1e3a8a', accent: '#2563eb' },
  // mark subtypes
  support:    { bg: '#f0fdf4', border: '#86efac', text: '#14532d', accent: '#16a34a' },
  resistance: { bg: '#fff1f2', border: '#fda4af', text: '#9f1239', accent: '#dc2626' },
  target:     { bg: '#eff6ff', border: '#93c5fd', text: '#1e3a8a', accent: '#2563eb' },
  note_free:  { bg: '#fefce8', border: '#fde047', text: '#713f12', accent: '#ca8a04' },
};

function _nodeColors(node) {
  const subtype = node.data?.subtype || node.type;
  return NODE_COLORS[subtype] || NODE_COLORS[node.type] || NODE_COLORS.note;
}

function _renderNodes() {
  const layer = document.getElementById('nodes-layer');
  if (!layer) return;
  layer.innerHTML = '';

  const sorted = [..._canvas.nodes].sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0));
  sorted.forEach(node => {
    const el = _buildNodeEl(node);
    layer.appendChild(el);
  });
  if (window.lucide) window.lucide.createIcons({ nodes: layer.querySelectorAll('[data-lucide]') });
}

function _buildNodeEl(node) {
  const el = document.createElement('div');
  el.id = `node-${node.id}`;
  el.setAttribute('data-node-id', node.id);
  const { bg, border, text, accent } = _nodeColors(node);
  const isSelected = _selectedNodeId === node.id;

  el.style.cssText = `
    position: absolute;
    left: ${node.x}px; top: ${node.y}px;
    width: ${node.width}px; min-height: ${node.height}px;
    pointer-events: all; cursor: grab; user-select: none;
    background: ${bg}; border: 1.5px solid ${isSelected ? accent : border};
    border-radius: 10px; box-shadow: ${isSelected ? `0 0 0 2px ${accent}40` : '0 1px 3px rgba(0,0,0,0.08)'};
    overflow: visible; transition: box-shadow 0.1s;
  `;

  el.innerHTML = _nodeInnerHTML(node, text, accent);

  // Drag handles on all 4 sides
  ['top','right','bottom','left'].forEach(side => {
    const handle = document.createElement('div');
    handle.setAttribute('data-handle-side', side);
    handle.setAttribute('data-node-id', node.id);
    const isV = side === 'top' || side === 'bottom';
    handle.style.cssText = `
      position: absolute; pointer-events: all; cursor: crosshair; z-index: 10;
      ${side === 'top'    ? `top:-5px; left:50%; transform:translateX(-50%); width:16px; height:10px;` : ''}
      ${side === 'bottom' ? `bottom:-5px; left:50%; transform:translateX(-50%); width:16px; height:10px;` : ''}
      ${side === 'left'   ? `left:-5px; top:50%; transform:translateY(-50%); width:10px; height:16px;` : ''}
      ${side === 'right'  ? `right:-5px; top:50%; transform:translateY(-50%); width:10px; height:16px;` : ''}
    `;
    handle.innerHTML = `<div style="
      width: ${isV ? 10 : 6}px; height: ${isV ? 6 : 10}px;
      margin: auto; background: ${accent}; border-radius: 3px; border: 2px solid white;
      box-shadow: 0 1px 3px rgba(0,0,0,0.2);
    "></div>`;
    el.appendChild(handle);
  });

  return el;
}

function _nodeInnerHTML(node, text, accent) {
  const d = node.data || {};
  switch (node.type) {
    case 'image':
      return `
        <div class="node-drag-target" style="padding: 6px;">
          ${d.url ? `<img src="${d.url}" alt="${d.caption||''}"
            style="width:100%;border-radius:6px;display:block;max-height:140px;object-fit:cover;">` : ''}
          ${d.caption ? `<p style="font-size:11px;color:${text};margin-top:4px;padding:0 2px;">${d.caption}</p>` : ''}
          <button class="node-edit-btn" data-id="${node.id}"
            style="position:absolute;top:5px;right:5px;background:rgba(0,0,0,0.45);color:#fff;border:none;border-radius:5px;padding:3px 6px;font-size:10px;cursor:pointer;">✎</button>
        </div>`;

    case 'note':
    case 'note_free':
      return `
        <div class="node-drag-target" style="padding:10px 12px 8px; min-height:50px;">
          <p style="font-size:12px;color:${text};line-height:1.5;white-space:pre-wrap;">${d.text||'Nota vazia…'}</p>
          <button class="node-edit-btn" data-id="${node.id}"
            style="position:absolute;top:5px;right:5px;background:transparent;color:${accent};border:none;font-size:11px;cursor:pointer;">✎</button>
        </div>`;

    case 'level':
    case 'support':
    case 'resistance':
    case 'target':
      return `
        <div class="node-drag-target" style="padding:8px 12px; display:flex; align-items:center; gap:8px;">
          <div style="width:22px;height:22px;border-radius:5px;background:${accent};opacity:0.15;"></div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:11px;font-weight:500;color:${text};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${d.label||'Nível'}</div>
            ${d.price ? `<div style="font-size:10px;color:${accent};font-family:monospace;">${d.price}</div>` : ''}
          </div>
          <button class="node-edit-btn" data-id="${node.id}"
            style="background:transparent;color:${accent};border:none;font-size:11px;cursor:pointer;">✎</button>
        </div>`;

    default: {
      const abbr = d.abbr || '?';
      return `
        <div class="node-drag-target" style="padding:8px 10px 8px 10px;">
          <div style="display:flex;align-items:flex-start;gap:8px;">
            <div style="width:28px;height:28px;border-radius:7px;background:${accent};color:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;shrink:0;">${abbr}</div>
            <div style="flex:1;min-width:0;padding-top:2px;">
              <div style="font-size:12px;font-weight:600;color:${text};line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${d.label||node.type}</div>
              ${d.probability ? `<div style="font-size:10px;color:${accent};margin-top:2px;">${d.probability}</div>` : ''}
              ${d.notes ? `<div style="font-size:10px;color:${text};opacity:0.65;margin-top:3px;white-space:pre-wrap;">${d.notes}</div>` : ''}
            </div>
          </div>
          <button class="node-edit-btn" data-id="${node.id}"
            style="position:absolute;top:5px;right:5px;background:transparent;color:${accent};border:none;font-size:11px;cursor:pointer;">✎</button>
        </div>`;
    }
  }
}

/* ─── EDGE RENDERING ────────────────────────────────────────────────────────── */

function _renderEdges() {
  const layer = document.getElementById('edges-layer');
  if (!layer) return;
  layer.innerHTML = '';

  _canvas.edges.forEach(edge => {
    const srcNode = _canvas.nodes.find(n => n.id === edge.sourceId);
    const tgtNode = _canvas.nodes.find(n => n.id === edge.targetId);
    if (!srcNode || !tgtNode) return;

    const src = _nodeCenter(srcNode);
    const tgt = _nodeCenter(tgtNode);
    const d   = _bezier(src.x, src.y, tgt.x, tgt.y);
    const stroke = edge.color || '#6366f1';
    const isDashed = edge.edgeType === 'dashed';
    const isBi     = edge.edgeType === 'bidirectional';
    const isSelected = _selectedEdgeId === edge.id;

    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', stroke);
    path.setAttribute('stroke-width', isSelected ? '2.5' : '1.5');
    path.setAttribute('stroke-linecap', 'round');
    if (isDashed) path.setAttribute('stroke-dasharray', '6 4');
    path.setAttribute('marker-end', 'url(#ah)');
    if (isBi) path.setAttribute('marker-start', 'url(#ah)');
    path.style.cursor = 'pointer';
    path.setAttribute('data-edge-id', edge.id);

    // Hit area
    const hit = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    hit.setAttribute('d', d); hit.setAttribute('fill', 'none');
    hit.setAttribute('stroke', 'transparent'); hit.setAttribute('stroke-width', '14');
    hit.style.cursor = 'pointer';
    hit.setAttribute('data-edge-id', edge.id);

    // Label
    if (edge.label) {
      const mid = _bezierMidpoint(src.x, src.y, tgt.x, tgt.y);
      const txt = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      txt.setAttribute('x', mid.x); txt.setAttribute('y', mid.y - 5);
      txt.setAttribute('text-anchor', 'middle');
      txt.setAttribute('font-size', '10'); txt.setAttribute('fill', stroke);
      txt.setAttribute('font-family', 'Inter, sans-serif');
      txt.textContent = edge.label;
      layer.appendChild(txt);
    }

    layer.appendChild(path);
    layer.appendChild(hit);
  });
}

function _nodeCenter(node) {
  return { x: node.x + node.width / 2, y: node.y + node.height / 2 };
}

function _bezier(x1, y1, x2, y2) {
  const dx = Math.abs(x2 - x1);
  const cp = Math.max(dx * 0.55, 60);
  return `M ${x1} ${y1} C ${x1 + cp} ${y1}, ${x2 - cp} ${y2}, ${x2} ${y2}`;
}

function _bezierMidpoint(x1, y1, x2, y2) {
  return { x: (x1 + x2) / 2, y: (y1 + y2) / 2 };
}

/* ─── VIEWPORT ──────────────────────────────────────────────────────────────── */

function _applyViewport() {
  const t = document.getElementById('canvas-transform');
  const bg = document.getElementById('canvas-container');
  if (!t) return;
  const { x, y, scale } = _canvas.viewport;
  t.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
  if (bg) {
    bg.style.backgroundPosition = `${x}px ${y}px`;
    bg.style.backgroundSize = `${24 * scale}px ${24 * scale}px`;
  }
  const lbl = document.getElementById('zoom-label');
  if (lbl) lbl.textContent = `${Math.round(scale * 100)}%`;
}

/* ─── AUTO-SAVE ─────────────────────────────────────────────────────────────── */

function _triggerSave() {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(async () => {
    if (!_currentMapId) return;
    await saveMapMetadata(_currentMapId, _canvas.title, _canvas.tags, _canvas.description, _canvas.viewport);
    const badge = document.getElementById('save-badge');
    if (badge) {
      badge.style.opacity = '1';
      setTimeout(() => { badge.style.opacity = '0'; }, 2000);
    }
  }, 1800);
}

/* ─── EVENT BINDING ─────────────────────────────────────────────────────────── */

function _bindEditorEvents() {
  const canvasEl   = document.getElementById('canvas-container');
  const nodesLayer = document.getElementById('nodes-layer');
  const edgesSvg   = document.getElementById('edges-svg');

  // Back
  document.getElementById('editor-back-btn')?.addEventListener('click', async () => {
    _cleanGlobal();
    _maps = await loadAllMaps();
    _view = 'gallery';
    _render();
  });

  // Title rename
  const titleInput = document.getElementById('editor-title');
  titleInput?.addEventListener('input', e => {
    _canvas.title = e.target.value;
    _triggerSave();
  });

  // Sidebar toggle
  document.getElementById('sidebar-toggle')?.addEventListener('click', () => {
    _sidebarOpen = !_sidebarOpen;
    const sb = document.getElementById('right-sidebar');
    const toggle = document.getElementById('sidebar-toggle');
    if (sb) {
      sb.style.width = _sidebarOpen ? '248px' : '0px';
      sb.innerHTML = _sidebarOpen ? _renderSidebarContent() : '';
      if (window.lucide) window.lucide.createIcons({ nodes: sb.querySelectorAll('[data-lucide]') });
      _bindSidebarEvents();
    }
    if (toggle) {
      toggle.style.right = (_sidebarOpen ? 248 : 0) + 'px';
      toggle.textContent = _sidebarOpen ? '›' : '‹';
    }
  });

  // Category toggles in sidebar
  _bindSidebarEvents();

  // Clear canvas
  document.getElementById('clear-canvas-btn')?.addEventListener('click', async () => {
    if (!confirm('Limpar todo o canvas? Os nós e conexões serão excluídos permanentemente.')) return;
    for (const n of _canvas.nodes) await deleteNodeDB(n.id);
    for (const e of _canvas.edges) await deleteEdgeDB(e.id);
    _canvas.nodes = []; _canvas.edges = [];
    _renderNodes(); _renderEdges();
  });

  // Tags modal
  document.getElementById('editor-tags-btn')?.addEventListener('click', () => {
    document.getElementById('tags-modal')?.classList.remove('hidden');
  });
  document.getElementById('tags-modal-close')?.addEventListener('click', () => {
    document.getElementById('tags-modal')?.classList.add('hidden');
  });

  // Add tag
  const addTag = () => {
    const input = document.getElementById('tag-input');
    const val = input?.value?.trim().toLowerCase().replace(/\s+/g, '-');
    if (!val || _canvas.tags.includes(val)) return;
    _canvas.tags.push(val);
    input.value = '';
    _refreshTagsModal();
    _triggerSave();
    // Update header badge
    const btn = document.getElementById('editor-tags-btn');
    if (btn) btn.innerHTML = `
      <i data-lucide="tag" class="w-3.5 h-3.5"></i>
      <span class="bg-zinc-900 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold">${_canvas.tags.length}</span>
      Tags`;
    if (window.lucide) window.lucide.createIcons({ nodes: btn?.querySelectorAll('[data-lucide]') });
  };
  document.getElementById('tag-add-btn')?.addEventListener('click', addTag);
  document.getElementById('tag-input')?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } });

  // Zoom buttons
  document.getElementById('zoom-in-btn')?.addEventListener('click', () => {
    _canvas.viewport.scale = Math.min(3, _canvas.viewport.scale * 1.2);
    _applyViewport(); _triggerSave();
  });
  document.getElementById('zoom-out-btn')?.addEventListener('click', () => {
    _canvas.viewport.scale = Math.max(0.15, _canvas.viewport.scale / 1.2);
    _applyViewport(); _triggerSave();
  });
  document.getElementById('zoom-reset-btn')?.addEventListener('click', () => {
    _canvas.viewport = { x: 0, y: 0, scale: 1 };
    _applyViewport(); _triggerSave();
  });

  // ── Canvas events ──────────────────────────────────────────────────────────
  if (canvasEl) {
    // Wheel zoom
    canvasEl.addEventListener('wheel', e => {
      e.preventDefault();
      let delta = e.deltaY;
      if (e.deltaMode === 1) delta *= 16;
      const zf = Math.exp(-delta * 0.002);
      const ns = Math.min(3, Math.max(0.15, _canvas.viewport.scale * zf));
      const rect = canvasEl.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      _canvas.viewport.x = mx - (mx - _canvas.viewport.x) * (ns / _canvas.viewport.scale);
      _canvas.viewport.y = my - (my - _canvas.viewport.y) * (ns / _canvas.viewport.scale);
      _canvas.viewport.scale = ns;
      _applyViewport();
    }, { passive: false });

    // Pan start (middle-click or empty-area left-click)
    canvasEl.addEventListener('mousedown', e => {
      const target = e.target;
      const isBackground = ['canvas-container','canvas-transform','edges-svg','nodes-layer'].includes(target.id);
      if (e.button === 1 || (e.button === 0 && isBackground)) {
        _isPanning = true;
        _panStartX = e.clientX - _canvas.viewport.x;
        _panStartY = e.clientY - _canvas.viewport.y;
        canvasEl.style.cursor = 'grabbing';
        e.preventDefault();
      }
    });

    // Drag & drop from sidebar
    canvasEl.addEventListener('dragover', e => e.preventDefault());
    canvasEl.addEventListener('drop', e => {
      e.preventDefault();
      const raw = e.dataTransfer.getData('application/json');
      if (!raw) return;
      const cardData = JSON.parse(raw);
      const rect   = canvasEl.getBoundingClientRect();
      const x = (e.clientX - rect.left - _canvas.viewport.x) / _canvas.viewport.scale;
      const y = (e.clientY - rect.top  - _canvas.viewport.y) / _canvas.viewport.scale;
      _addNode(cardData, x - 80, y - 30);
    });
  }

  // ── Node layer events ───────────────────────────────────────────────────────
  if (nodesLayer) {
    nodesLayer.addEventListener('mousedown', e => {
      const nodeEl = e.target.closest('[data-node-id]');
      const handleEl = e.target.closest('[data-handle-side]');
      const editBtn = e.target.closest('.node-edit-btn');

      if (editBtn) {
        e.stopPropagation();
        _openNodeModal(editBtn.getAttribute('data-id'));
        return;
      }

      if (handleEl && e.button === 0) {
        // Start drawing edge
        e.stopPropagation();
        _isDraggingEdge = true;
        _edgeSourceId   = handleEl.getAttribute('data-node-id');
        const edgeTemp  = document.getElementById('edge-temp');
        if (edgeTemp) edgeTemp.style.display = '';
        return;
      }

      if (nodeEl && e.button === 0) {
        e.stopPropagation();
        const nid = nodeEl.getAttribute('data-node-id');
        const nd  = _canvas.nodes.find(n => n.id === nid);
        if (!nd) return;
        _isDraggingNode = true;
        _hasDragged     = false;
        _dragNodeId     = nid;
        _dragStartX     = e.clientX;
        _dragStartY     = e.clientY;
        _nodeStartX     = nd.x;
        _nodeStartY     = nd.y;
        _selectNode(nid);
      }
    });

    nodesLayer.addEventListener('click', e => {
      const nodeEl = e.target.closest('[data-node-id]');
      if (!_hasDragged && nodeEl) {
        _selectNode(nodeEl.getAttribute('data-node-id'));
      } else if (!nodeEl) {
        _deselectAll();
      }
    });
  }

  // Edge click (on the SVG)
  if (edgesSvg) {
    edgesSvg.addEventListener('click', e => {
      const eid = e.target.getAttribute('data-edge-id');
      if (eid) {
        _selectedEdgeId = eid;
        _selectedNodeId = null;
        _renderEdges();
      }
    });
    edgesSvg.addEventListener('dblclick', e => {
      const eid = e.target.getAttribute('data-edge-id');
      if (eid) { _deleteEdge(eid); }
    });
  }

  // ── Global mouse events ─────────────────────────────────────────────────────
  _addGlobal('mousemove', e => {
    if (_isPanning) {
      _canvas.viewport.x = e.clientX - _panStartX;
      _canvas.viewport.y = e.clientY - _panStartY;
      _applyViewport();
    }

    if (_isDraggingNode && _dragNodeId) {
      const dx = (e.clientX - _dragStartX) / _canvas.viewport.scale;
      const dy = (e.clientY - _dragStartY) / _canvas.viewport.scale;
      if (Math.abs(dx) > 2 || Math.abs(dy) > 2) _hasDragged = true;
      const node = _canvas.nodes.find(n => n.id === _dragNodeId);
      if (node) {
        node.x = _nodeStartX + dx;
        node.y = _nodeStartY + dy;
        const el = document.getElementById(`node-${node.id}`);
        if (el) { el.style.left = node.x + 'px'; el.style.top = node.y + 'px'; }
        _renderEdges();
      }
    }

    if (_isDraggingEdge) {
      const canvasEl = document.getElementById('canvas-container');
      const rect = canvasEl?.getBoundingClientRect();
      if (!rect) return;
      const mx = (e.clientX - rect.left - _canvas.viewport.x) / _canvas.viewport.scale;
      const my = (e.clientY - rect.top  - _canvas.viewport.y) / _canvas.viewport.scale;
      const srcNode = _canvas.nodes.find(n => n.id === _edgeSourceId);
      if (srcNode) {
        const src = _nodeCenter(srcNode);
        const edgeTmp = document.getElementById('edge-temp');
        if (edgeTmp) edgeTmp.setAttribute('d', _bezier(src.x, src.y, mx, my));
      }
    }
  });

  _addGlobal('mouseup', e => {
    if (_isPanning) { _isPanning = false; const c = document.getElementById('canvas-container'); if (c) c.style.cursor = 'default'; _triggerSave(); }

    if (_isDraggingNode && _dragNodeId && _hasDragged) {
      const node = _canvas.nodes.find(n => n.id === _dragNodeId);
      if (node) upsertNode(node, _currentMapId);
      _triggerSave();
    }
    _isDraggingNode = false; _dragNodeId = null;

    if (_isDraggingEdge) {
      _isDraggingEdge = false;
      const edgeTmp = document.getElementById('edge-temp');
      if (edgeTmp) { edgeTmp.style.display = 'none'; edgeTmp.setAttribute('d', ''); }

      // Check if mouse is over a node handle
      const target = e.target.closest?.('[data-node-id]');
      if (target) {
        const targetId = target.getAttribute('data-node-id');
        if (targetId && targetId !== _edgeSourceId) {
          _addEdge(_edgeSourceId, targetId);
        }
      }
      _edgeSourceId = null;
    }
  });

  // Keyboard: delete selected
  _addGlobal('keydown', async e => {
    if ((e.key === 'Delete' || e.key === 'Backspace') && !_modalOpen) {
      const tag = document.activeElement?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (_selectedNodeId) {
        e.preventDefault();
        await _deleteNode(_selectedNodeId);
      } else if (_selectedEdgeId) {
        e.preventDefault();
        await _deleteEdge(_selectedEdgeId);
      }
    }
    if (e.key === 'Escape') {
      _deselectAll();
      document.getElementById('node-modal')?.classList.add('hidden');
      document.getElementById('tags-modal')?.classList.add('hidden');
      _modalOpen = false;
    }
  });

  // Paste (Ctrl+V = image)
  _addGlobal('paste', async e => {
    if (_view !== 'editor') return;
    const items = [...(e.clipboardData?.items || [])];
    const imageItem = items.find(i => i.type.startsWith('image/'));
    if (!imageItem) return;
    e.preventDefault();
    const file = imageItem.getAsFile();
    if (!file) return;
    const result = await uploadImageFile(file);
    if (!result) return;
    const vp = _canvas.viewport;
    const cx = document.getElementById('canvas-container');
    const x = (-vp.x + (cx?.clientWidth  || 500) / 2 - 120) / vp.scale;
    const y = (-vp.y + (cx?.clientHeight || 400) / 2 - 80)  / vp.scale;
    _addNode({ type: 'image', subtype: 'image', label: 'Imagem', abbr: '🖼' }, x, y, {
      url: result.url, storage_path: result.path, caption: ''
    });
  });

  // Concept search modal (for concept cards)
  _bindConceptSearch();
}

function _bindSidebarEvents() {
  const sb = document.getElementById('right-sidebar');
  if (!sb) return;

  sb.querySelectorAll('.cat-header').forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.getAttribute('data-cat-key');
      _openCategoryKey = _openCategoryKey === key ? null : key;
      const wrapper = sb.querySelector(`.sidebar-category[data-cat-key="${key}"]`);
      if (!wrapper) return;
      const items = wrapper.querySelector('.cat-items');
      const icon  = wrapper.querySelector('[data-lucide]');
      if (items) items.classList.toggle('hidden');
      const isOpen = !items?.classList.contains('hidden');
      if (icon) { icon.setAttribute('data-lucide', isOpen ? 'chevron-up' : 'chevron-down'); }
      if (window.lucide) window.lucide.createIcons({ nodes: wrapper.querySelectorAll('[data-lucide]') });
    });
  });

  sb.querySelectorAll('.sidebar-card').forEach(card => {
    card.addEventListener('dragstart', e => {
      e.dataTransfer.setData('application/json', JSON.stringify({
        type:    card.getAttribute('data-card-type'),
        subtype: card.getAttribute('data-card-subtype'),
        label:   card.getAttribute('data-card-label'),
      }));
      e.dataTransfer.effectAllowed = 'move';
    });
  });
}

function _refreshTagsModal() {
  const container = document.getElementById('tags-current');
  if (!container) return;
  container.innerHTML = _canvas.tags.map(t => `
    <span class="flex items-center gap-1 text-xs bg-zinc-100 text-zinc-700 px-2 py-1 rounded-lg border border-zinc-200">
      ${t}
      <button class="tag-remove hover:text-red-500 transition-colors leading-none" data-tag="${t}">×</button>
    </span>`).join('');
  container.querySelectorAll('.tag-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      const tag = btn.getAttribute('data-tag');
      _canvas.tags = _canvas.tags.filter(t => t !== tag);
      _refreshTagsModal();
      _triggerSave();
    });
  });
}

function _bindConceptSearch() {
  // Triggered by concept card type — handled in _openNodeModal
}

/* ─── NODE OPERATIONS ───────────────────────────────────────────────────────── */

async function _addNode(cardData, x, y, extraData = {}) {
  const type = cardData.type;
  const lib  = Object.values(CARD_LIBRARY).flatMap(c => c.items).find(i => i.subtype === cardData.subtype);

  const node = {
    id: uuid(), type,
    x: Math.round(x), y: Math.round(y),
    width: type === 'image' ? 180 : type === 'note' || type === 'note_free' ? 160 : 160,
    height: type === 'image' ? 120 : 52,
    zIndex: _canvas.nodes.length,
    data: {
      label:    cardData.label || lib?.label || type,
      subtype:  cardData.subtype,
      abbr:     lib?.abbr || '?',
      direction: lib?.dir || null,
      ...extraData,
    },
  };

  if (type === 'concept') {
    // Open concept picker
    _openConceptPicker(async conceptData => {
      node.data = { ...node.data, ...conceptData };
      _canvas.nodes.push(node);
      await upsertNode(node, _currentMapId);
      _renderNodes();
    });
    return;
  }

  _canvas.nodes.push(node);
  await upsertNode(node, _currentMapId);
  _renderNodes();
  _selectNode(node.id);
  _triggerSave();
}

async function _deleteNode(nodeId) {
  _canvas.nodes    = _canvas.nodes.filter(n => n.id !== nodeId);
  _canvas.edges    = _canvas.edges.filter(e => e.sourceId !== nodeId && e.targetId !== nodeId);
  _selectedNodeId  = null;
  await deleteNodeDB(nodeId);
  _renderNodes(); _renderEdges();
  _triggerSave();
}

async function _addEdge(sourceId, targetId) {
  const edge = {
    id: uuid(), sourceId, targetId,
    edgeType: 'arrow', label: '', color: '#6366f1',
  };
  _canvas.edges.push(edge);
  await upsertEdge(edge, _currentMapId);
  _renderEdges();
  _triggerSave();
}

async function _deleteEdge(edgeId) {
  _canvas.edges   = _canvas.edges.filter(e => e.id !== edgeId);
  _selectedEdgeId = null;
  await deleteEdgeDB(edgeId);
  _renderEdges();
  _triggerSave();
}

function _selectNode(nodeId) {
  const prev = _selectedNodeId;
  _selectedNodeId = nodeId;
  _selectedEdgeId = null;

  // Refresh only affected nodes to avoid full re-render
  if (prev) {
    const pn = _canvas.nodes.find(n => n.id === prev);
    if (pn) {
      const el = document.getElementById(`node-${prev}`);
      if (el) { const { border } = _nodeColors(pn); el.style.border = `1.5px solid ${border}`; el.style.boxShadow = '0 1px 3px rgba(0,0,0,0.08)'; }
    }
  }
  const cn = _canvas.nodes.find(n => n.id === nodeId);
  if (cn) {
    const el = document.getElementById(`node-${nodeId}`);
    if (el) { const { accent } = _nodeColors(cn); el.style.border = `1.5px solid ${accent}`; el.style.boxShadow = `0 0 0 2px ${accent}40`; }
  }
}

function _deselectAll() {
  if (_selectedNodeId) {
    const cn = _canvas.nodes.find(n => n.id === _selectedNodeId);
    if (cn) {
      const el = document.getElementById(`node-${_selectedNodeId}`);
      if (el) { const { border } = _nodeColors(cn); el.style.border = `1.5px solid ${border}`; el.style.boxShadow = '0 1px 3px rgba(0,0,0,0.08)'; }
    }
  }
  _selectedNodeId = null;
  _selectedEdgeId = null;
  _renderEdges();
}

/* ─── NODE EDIT MODAL ───────────────────────────────────────────────────────── */

function _openNodeModal(nodeId) {
  const node = _canvas.nodes.find(n => n.id === nodeId);
  if (!node) return;
  _editNodeId = nodeId;
  _modalOpen  = true;
  const d = node.data || {};
  const modal   = document.getElementById('node-modal');
  const content = document.getElementById('node-modal-content');
  if (!modal || !content) return;

  const probOptions = ['','40-50%','50-60%','60-70%','70-80%','80-90%'];

  content.innerHTML = `
    <div class="flex items-center justify-between mb-4">
      <h3 class="text-sm font-bold text-zinc-900">Editar ${d.label || node.type}</h3>
      <button id="node-modal-close" class="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-zinc-600 transition-colors">
        <i data-lucide="x" class="w-4 h-4"></i>
      </button>
    </div>

    <div class="space-y-3">
      <div>
        <label class="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Rótulo</label>
        <input id="nm-label" type="text" value="${_escAttr(d.label||'')}" placeholder="Nome / descrição..."
          class="mt-1 w-full text-xs bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-400 transition-colors"/>
      </div>

      ${node.type === 'setup' || node.type === 'pattern' ? `
      <div>
        <label class="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Probabilidade</label>
        <select id="nm-prob"
          class="mt-1 w-full text-xs bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-400 transition-colors">
          ${probOptions.map(p => `<option value="${p}" ${d.probability===p?'selected':''}>${p||'Sem probabilidade'}</option>`).join('')}
        </select>
      </div>` : ''}

      ${node.type === 'note' || node.type === 'note_free' ? `
      <div>
        <label class="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Texto</label>
        <textarea id="nm-notes" rows="4"
          class="mt-1 w-full text-xs bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-400 transition-colors resize-none"
          placeholder="Sua anotação...">${d.text||''}</textarea>
      </div>` : `
      <div>
        <label class="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Notas</label>
        <textarea id="nm-notes" rows="3"
          class="mt-1 w-full text-xs bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-400 transition-colors resize-none"
          placeholder="Observações rápidas...">${d.notes||''}</textarea>
      </div>`}

      ${node.type === 'level' || node.type === 'support' || node.type === 'resistance' || node.type === 'target' ? `
      <div>
        <label class="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Preço / Valor</label>
        <input id="nm-price" type="text" value="${_escAttr(d.price||'')}" placeholder="ex: 5.280.00"
          class="mt-1 w-full text-xs bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-400 transition-colors font-mono"/>
      </div>` : ''}

      ${node.type === 'image' ? `
      <div>
        <label class="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Legenda</label>
        <input id="nm-caption" type="text" value="${_escAttr(d.caption||'')}" placeholder="Legenda da imagem..."
          class="mt-1 w-full text-xs bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-2 focus:outline-none focus:border-zinc-400 transition-colors"/>
        <label class="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider mt-2 block">Substituir imagem</label>
        <input type="file" id="nm-img-file" accept="image/*" class="mt-1 text-xs w-full"/>
      </div>` : ''}
    </div>

    <div class="flex items-center justify-between mt-4 pt-3 border-t border-zinc-100">
      <button id="nm-delete"
        class="flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 hover:bg-red-50 px-3 py-1.5 rounded-lg transition-colors">
        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i> Excluir
      </button>
      <div class="flex gap-2">
        <button id="nm-cancel" class="px-3 py-1.5 text-xs text-zinc-500 hover:bg-zinc-100 rounded-lg transition-colors">Cancelar</button>
        <button id="nm-save" class="px-4 py-1.5 text-xs bg-zinc-900 hover:bg-zinc-800 text-white font-semibold rounded-lg transition-colors">Salvar</button>
      </div>
    </div>
  `;

  modal.classList.remove('hidden');
  if (window.lucide) window.lucide.createIcons({ nodes: content.querySelectorAll('[data-lucide]') });

  const close = () => { modal.classList.add('hidden'); _modalOpen = false; _editNodeId = null; };
  document.getElementById('node-modal-close')?.addEventListener('click', close);
  document.getElementById('nm-cancel')?.addEventListener('click', close);
  document.getElementById('nm-delete')?.addEventListener('click', async () => {
    close();
    await _deleteNode(nodeId);
  });

  document.getElementById('nm-save')?.addEventListener('click', async () => {
    const label   = document.getElementById('nm-label')?.value || '';
    const notes   = document.getElementById('nm-notes')?.value || '';
    const prob    = document.getElementById('nm-prob')?.value   || '';
    const price   = document.getElementById('nm-price')?.value  || '';
    const caption = document.getElementById('nm-caption')?.value || '';
    const imgFile = document.getElementById('nm-img-file')?.files?.[0];

    node.data = { ...node.data, label, notes, probability: prob, price, caption,
      ...(node.type === 'note' || node.type === 'note_free' ? { text: notes } : {}),
    };

    if (imgFile) {
      const result = await uploadImageFile(imgFile);
      if (result) { node.data.url = result.url; node.data.storage_path = result.path; }
    }

    await upsertNode(node, _currentMapId);
    _renderNodes();
    _triggerSave();
    close();
  });

  modal.addEventListener('click', e => { if (e.target === modal) close(); });
}

/* ─── CONCEPT PICKER ────────────────────────────────────────────────────────── */

function _openConceptPicker(onSelect) {
  const { concepts } = store.getState();
  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center';
  modal.innerHTML = `
    <div class="bg-white rounded-2xl shadow-xl w-96 p-5">
      <div class="flex items-center justify-between mb-3">
        <h3 class="text-sm font-bold text-zinc-800">Selecionar Conceito</h3>
        <button id="cp-close" class="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-400">
          <i data-lucide="x" class="w-4 h-4"></i>
        </button>
      </div>
      <div class="relative mb-2">
        <i data-lucide="search" class="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"></i>
        <input id="cp-search" type="text" placeholder="Buscar conceito..."
          class="w-full text-xs bg-zinc-50 border border-zinc-200 rounded-lg pl-9 pr-3 py-2 focus:outline-none focus:border-zinc-400"/>
      </div>
      <div id="cp-list" class="h-52 overflow-y-auto space-y-1"></div>
    </div>
  `;
  document.body.appendChild(modal);
  if (window.lucide) window.lucide.createIcons({ nodes: modal.querySelectorAll('[data-lucide]') });
  _modalOpen = true;

  const close = () => { modal.remove(); _modalOpen = false; };
  modal.querySelector('#cp-close')?.addEventListener('click', close);
  modal.addEventListener('click', e => { if (e.target === modal) close(); });

  const renderList = q => {
    const list = modal.querySelector('#cp-list');
    if (!list) return;
    const filtered = q
      ? concepts.filter(c => c.name.toLowerCase().includes(q.toLowerCase())).slice(0, 20)
      : concepts.slice(0, 30);
    list.innerHTML = filtered.map(c => `
      <button class="cp-item w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-zinc-50 transition-colors" data-cid="${c.id}">
        <span class="text-[10px] font-bold px-1.5 py-0.5 rounded border text-emerald-700 bg-emerald-50 border-emerald-200 shrink-0">${c.abcCategory||'C'}</span>
        <span class="text-xs text-zinc-700 truncate">${c.name}</span>
        <span class="text-[10px] text-zinc-400 ml-auto shrink-0">${c.masteryPercentage||0}%</span>
      </button>`).join('');
    list.querySelectorAll('.cp-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const c = concepts.find(x => x.id === btn.getAttribute('data-cid'));
        if (c) onSelect({ concept_id: c.id, concept_name: c.name, mastery: c.masteryPercentage, label: c.name });
        close();
      });
    });
  };
  renderList('');
  modal.querySelector('#cp-search')?.addEventListener('input', e => renderList(e.target.value.trim()));
}

/* ─── UTILS ─────────────────────────────────────────────────────────────────── */

function _escAttr(s) {
  return String(s || '').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
